
Arrow keys to move
Shift to fire the weapon
Control to slow down the plane

Enemies are worth 5 points

Powerups are worth how much bullets they give you (3, 5, and 10)